package com.app.springboot.cruddemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.springboot.cruddemo.entity.Festival;


public interface FestivalRepository extends JpaRepository<Festival, Integer> {

}

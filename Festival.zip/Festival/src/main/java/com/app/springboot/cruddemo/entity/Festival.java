package com.app.springboot.cruddemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="festival")
public class Festival {
	@Id
	@Column(name="fid")
	private int fid;
	@Column(name="fname")
	private String fname;
	@Column(name="sid")
	private int sid;
	public Festival() {
		// TODO Auto-generated constructor stub
	}
	public Festival(int fid, String fname, int sid) {
		super();
		this.fid = fid;
		this.fname = fname;
		this.sid = sid;
	}
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	
}

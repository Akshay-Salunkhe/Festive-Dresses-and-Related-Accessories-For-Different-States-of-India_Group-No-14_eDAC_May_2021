package com.app.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.springboot.cruddemo.entity.State;
import com.app.springboot.cruddemo.service.StateService;

@RestController
@RequestMapping("/api")
public class StateRestController {
		
	private StateService stateService;
	 public StateRestController() {
		// TODO Auto-generated constructor stub
	}
	 @Autowired
	public StateRestController(StateService stateService) {
		super();
		this.stateService = stateService;
	}
	@GetMapping("/state")
	public List<State> findAll(){
		return stateService.findAll();
	}
}

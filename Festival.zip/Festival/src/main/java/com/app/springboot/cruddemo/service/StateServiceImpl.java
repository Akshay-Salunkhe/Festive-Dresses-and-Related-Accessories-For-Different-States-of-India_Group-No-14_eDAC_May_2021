package com.app.springboot.cruddemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.springboot.cruddemo.dao.StateRepository;
import com.app.springboot.cruddemo.dao.UserRepository;
import com.app.springboot.cruddemo.entity.State;

@Service
public class StateServiceImpl implements StateService {
	@Autowired
	private StateRepository stateRepository;
	
	

	public StateServiceImpl(StateRepository stateRepository) {
		super();
		this.stateRepository = stateRepository;
	}



	@Override
	public List<State> findAll() {
		// TODO Auto-generated method stub
		return stateRepository.findAll();
	}

	
}

package com.app.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.springboot.cruddemo.entity.Festival;
import com.app.springboot.cruddemo.entity.User;
import com.app.springboot.cruddemo.service.FestivalService;

@RestController
@RequestMapping("/api")
public class FestivalRestController {
		private FestivalService festivalService;
		
		public FestivalRestController() {
			// TODO Auto-generated constructor stub
		}
		@Autowired
		public FestivalRestController(FestivalService festivalService) {
			super();
			this.festivalService = festivalService;
		}
		
		@GetMapping("/festival")
		public List<Festival> findAll(){
			return festivalService.findAll();
		}
}

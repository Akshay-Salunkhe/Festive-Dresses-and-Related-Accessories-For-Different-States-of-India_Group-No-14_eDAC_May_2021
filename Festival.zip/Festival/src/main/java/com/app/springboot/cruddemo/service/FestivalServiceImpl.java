package com.app.springboot.cruddemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.springboot.cruddemo.dao.FestivalRepository;
import com.app.springboot.cruddemo.entity.Festival;

@Service
public class FestivalServiceImpl implements FestivalService {
	@Autowired
	private FestivalRepository festivalRepository;

	public FestivalServiceImpl(FestivalRepository festivalRepository) {
		super();
		this.festivalRepository = festivalRepository;
	}

	@Override
	public List<Festival> findAll() {
		// TODO Auto-generated method stub
		return festivalRepository.findAll();
	}
 
}

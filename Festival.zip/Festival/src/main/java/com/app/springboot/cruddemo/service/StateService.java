package com.app.springboot.cruddemo.service;

import java.util.List;

import com.app.springboot.cruddemo.entity.State;


public interface StateService {
	 public List<State> findAll();
}

package com.app.springboot.cruddemo.service;

import java.util.List;

import com.app.springboot.cruddemo.entity.Festival;

public interface FestivalService {
		public List<Festival> findAll();
}

package com.app.springboot.cruddemo.service;

import java.util.List;

import com.app.springboot.cruddemo.entity.User;



public interface UserService {

	 public List<User> findAll();

}